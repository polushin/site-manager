'use strict';
var myApp = angular.module('myApp', []);

myApp.controller('myAppCtrl', ['$scope','$rootScope', 'SiteManager', function($scope, $rootScope, SiteManager){
    SiteManager.loadSites();

    $scope.sites = SiteManager.getSites();
    $scope.currentContent = '';

    $scope.setActiveSite = function(site){
        $scope.currentSite = site;
        $scope.currentContent = site.content;
    };

    $scope.newSite = function(){
        $scope.setActiveSite({id:0, content:"<!--html code-->"});
    };

    $scope.saveSite = function(){
        console.log($scope.currentContent);
    };

    $scope.isNewSite = function(){
        if ((typeof $scope.currentSite == 'object') && ($scope.currentSite.id == 0)) {
            return true;
        }
        return false;
    };

    $rootScope.$on('sitesLoadedEvent', function(event, args) {
        $scope.sites = SiteManager.getSites();
        if ($scope.sites.length > 0) {
            $scope.setActiveSite($scope.sites[0]);
        }
    });
}]);

myApp.factory('SiteManager', ['$http', '$rootScope', function ($http, $rootScope) {
    var sites = [];

    return {
        loadSites: function(){
            $http({
                method: 'POST',
                url: '/sites.json'
            }).then(function successCallback(response) {
                sites = response.data;
                $rootScope.$emit('sitesLoadedEvent', '');
            }, function errorCallback(response) {

            });
        },

        getSites: function(){
            return sites;
        }
    }
}]);



